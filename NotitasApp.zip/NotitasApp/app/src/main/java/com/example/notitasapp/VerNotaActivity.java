package com.example.notitasapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class VerNotaActivity extends AppCompatActivity {
    private TextView texto1;
    private TextView texto2;
    private Button botonVolver;
    private Button botonBorrar;
    Intent pasarPantalla;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_ver_nota);

        texto1 = (TextView) findViewById(R.id.texto1_borrar);
        texto2 = (TextView) findViewById(R.id.texto2_borrar);
        botonVolver = (Button) findViewById(R.id.volverBoton_borrar);
        botonBorrar = (Button) findViewById(R.id.borrarBoton_borrar);

        ArrayList<String> notaObtenida;
        notaObtenida =

        botonVolver.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pasarPantalla = new Intent(VerNotaActivity.this, ListadoActivity.class);
                startActivity(pasarPantalla);

            }

        });
    }
}

