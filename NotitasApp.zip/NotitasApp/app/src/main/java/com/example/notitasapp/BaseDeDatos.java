package com.example.notitasapp;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import java.util.ArrayList;

public class BaseDeDatos extends SQLiteOpenHelper {
    public BaseDeDatos(@Nullable Context context) {
        super(context, "notitas", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        db.execSQL("CREATE TABLE notas(id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,nombre TEXT)");
        db.execSQL("INSERT INTO notas VALUES (NULL, 'ejemplo producto 1')");

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        db.execSQL("DROP TABLE IF EXISTS notas");
        this.onCreate(db);

    }
    public boolean borrarProducto(String id)
    {
        SQLiteDatabase db= this.getWritableDatabase();
        db.execSQL("DELETE FROM notas WHERE id="+id);
        return true;
    }

    public boolean insertarNotas(String nombre)
    {
        SQLiteDatabase db= this.getWritableDatabase();
        db.execSQL("INSERT INTO notas VALUES (NULL, '"+nombre+"')");
        return true;
    }

    public ArrayList<String> getAllNotas()
    {
        ArrayList<String> lista= new ArrayList<String>();

        SQLiteDatabase db= this.getReadableDatabase();

        Cursor res=null;
        res= db.rawQuery("SELECT * FROM notas",null);

        res.moveToLast();
        if (res.getCount()>0)
        {
            //En la tabla hay información
            res.moveToFirst();
            while(!res.isAfterLast())
            {
                lista.add(res.getString(0)+".-"+res.getString(1));

                res.moveToNext();
            }
        }

        return lista;

    }
    public ArrayList<String> getNote(int id)
    {
        ArrayList<Note> filas = new ArrayList<Note>();
        Cursor res=null;
        String contenido = "";
        if (numberOfNotes()>0){
            db = this.getReadableDatabase();
            res= db.rawQuery("SELECT * FROM notas WHERE id = "+id+" ORDER BY priority ASC",null);
        }


        res.moveToFirst();
        while (res.isAfterLast()==false){
            Note n = new Note(res.getInt(res.getColumnIndex("id")), res.getString((res.getColumnIndex("title"));
            filas.add(n);
            res.moveToNext();
        }

        return filas;

    }

}