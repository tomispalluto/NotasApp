package com.example.notitasapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class ListadoActivity extends AppCompatActivity {

    private EditText caja1;

    private Button boton1;

    private ListView lista1;

    private ArrayList<String> notas= new ArrayList<String>();
    private ArrayAdapter<String> adaptador;

    private String contenidoCaja1="";
    private String contenidoItem="";

    private BaseDeDatos db;

    private Intent pasarPantalla;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_listado);

        caja1= (EditText) findViewById(R.id.caja1_main);
        boton1=(Button) findViewById(R.id.boton_ver);
        lista1= (ListView) findViewById(R.id.lista1_ver);

        db= new BaseDeDatos(this);


        notas = db.getAllNotas();

        adaptador= new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1,notas);
        lista1.setAdapter(adaptador);

        lista1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                contenidoItem= parent.getItemAtPosition(position).toString();
                Intent pasarPantalla = new Intent(ListadoActivity.this, VerNotaActivity.class);
                finish();
                startActivity(pasarPantalla);

                //startActivity(pasarPantalla);
                /*String[] partes= contenidoItem.split(".-");
                //db.borrarProducto(partes[0]);

                listaProductos= db.getListadoProductos();
                adaptador.notifyDataSetChanged();
                adaptador.clear();
                adaptador.addAll(listaProductos);*/

            }
        });



        boton1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                contenidoCaja1= caja1.getText().toString();
                if (contenidoCaja1.equals(""))
                {
                    Toast.makeText(ListadoActivity.this, "Debe rellenar un producto", Toast.LENGTH_SHORT).show();
                }
                else
                {
                    Toast.makeText(ListadoActivity.this, "Insertar producto en la base de datos", Toast.LENGTH_SHORT).show();
                    db.insertarNotas(contenidoCaja1);
                    caja1.setText("");
                   /* pasarPantalla = new Intent(MainActivity.this, MainActivity.class);
                    startActivity(pasarPantalla);*/

                    notas = db.getAllNotas();
                    adaptador.notifyDataSetChanged();
                    adaptador.clear();
                    adaptador.addAll(notas);


                }

            }
        });




    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_main, menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle item selection.
        int id = item.getItemId();
        if (id == R.id.item_crear){
            pasarPantalla = new Intent(ListadoActivity.this, CrearNotaActivity.class);
            startActivity(pasarPantalla);
        }
        else if (id == R.id.item_opcion) {
            pasarPantalla = new Intent(ListadoActivity.this, VerNotaActivity.class);
            startActivity(pasarPantalla);
        }
        return true;
    }

}